﻿using Microsoft.AspNetCore.Mvc;
using projectCabutaje.Models;

namespace projectCabutaje.Controllers
{
    public class ContactController : Controller
    {
        private readonly string email = "contactCabutaje@gmail.com";
        private readonly string address = "Cebu, Philippines";
        public IActionResult Index()
        {
            ViewData["EmailAddress"] = email;
            ViewBag.Address = address;

            return View();
        }

        [HttpPost]

        public IActionResult Index(UCMain model)
        {
            ViewData["EmailAddress"] = email;
            ViewBag.Address = address;

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            //store the contact data in the database
            ViewBag.SuccessMessage = "Your message is received successfully";
            ModelState.Clear();
            return View();
        }
    }
}
